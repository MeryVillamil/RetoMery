package Room34.Decameron;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DecameronApplicationTests {

	@Test
	void contextLoads() {
	}

}
